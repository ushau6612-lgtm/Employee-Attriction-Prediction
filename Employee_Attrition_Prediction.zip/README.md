# Employee Attrition Prediction

## Synopsis
This project uses machine learning to predict whether an employee is likely to leave a company. The analysis considers salary, age, department, job role, working hours, years of experience, job satisfaction, overtime, distance from home, and years at the company.

## Objectives
- Analyze employee information.
- Understand employee attrition patterns.
- Identify factors related to employees leaving.
- Train a classification model.
- Predict employee attrition.
- Evaluate the model.

## Tools
Python, Pandas, Matplotlib, Scikit-learn

## Dataset Features
- employee_id
- age
- salary
- department
- job_role
- working_hours_per_week
- years_of_experience
- job_satisfaction
- overtime
- distance_from_home_km
- years_at_company
- attrition

Target:
- 0 = Employee Stayed
- 1 = Employee Left

## Data Preparation
- Loaded the employee dataset using Pandas.
- Checked for missing values.
- Filled missing numerical values using the median.
- Filled missing categorical values using the most frequent value.
- Standardized numerical features.
- One-hot encoded categorical features.
- Split the data into training and testing sets.

## Machine Learning Algorithm
Logistic Regression is used for binary classification.

## Evaluation
The program calculates:
- Accuracy
- Classification report
- Confusion matrix
- Attrition probability for a new employee
- Important model factors using logistic-regression coefficients

It also creates visualizations showing attrition by department and the relationship between job satisfaction and working hours.

## How to Run
1. Install Python.
2. Open a terminal in this project folder.
3. Install dependencies:
   pip install -r requirements.txt
4. Run:
   python employee_attrition_prediction.py

## Dataset Note
The included employee dataset is synthetic and intended for educational/classroom machine-learning practice. It does not contain real employee information.

## Important Note
Model outputs are for educational analysis and should not be used as the sole basis for employment decisions.
