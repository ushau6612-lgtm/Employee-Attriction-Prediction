# Employee Attrition Prediction
# Tools: Python, Pandas, Matplotlib, Scikit-learn

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Load dataset
data = pd.read_csv("employee_attrition.csv")

print("First 5 rows:")
print(data.head())

print("\nDataset shape:", data.shape)

# Check missing values
print("\nMissing values before cleaning:")
print(data.isnull().sum())

# Separate features and target
X = data.drop(columns=["employee_id", "attrition"])
y = data["attrition"]

numeric_features = [
    "age", "salary", "working_hours_per_week",
    "years_of_experience", "job_satisfaction",
    "distance_from_home_km", "years_at_company"
]

categorical_features = [
    "department", "job_role", "overtime"
]

# Preprocessing pipelines
numeric_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler())
])

categorical_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore"))
])

preprocessor = ColumnTransformer([
    ("num", numeric_pipeline, numeric_features),
    ("cat", categorical_pipeline, categorical_features)
])

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Build and train classification model
model = Pipeline([
    ("preprocessor", preprocessor),
    ("classifier", LogisticRegression(max_iter=2000, random_state=42))
])

model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Evaluation
accuracy = accuracy_score(y_test, y_pred)
print(f"\nModel Accuracy: {accuracy * 100:.2f}%")

print("\nClassification Report:")
print(classification_report(
    y_test, y_pred,
    target_names=["Stayed", "Left"],
    zero_division=0
))

print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# Predict a new employee
new_employee = pd.DataFrame([{
    "age": 28,
    "salary": 42000,
    "department": "Sales",
    "job_role": "Executive",
    "working_hours_per_week": 55,
    "years_of_experience": 5,
    "job_satisfaction": 2.0,
    "overtime": "Yes",
    "distance_from_home_km": 25,
    "years_at_company": 2
}])

prediction = model.predict(new_employee)[0]
attrition_probability = model.predict_proba(new_employee)[0][1]

print("\nExample Employee Prediction:",
      "Likely to Leave" if prediction == 1 else "Likely to Stay")
print(f"Attrition Probability: {attrition_probability * 100:.2f}%")

# Feature importance using logistic regression coefficients
feature_names = model.named_steps["preprocessor"].get_feature_names_out()
coefficients = model.named_steps["classifier"].coef_[0]

importance = pd.DataFrame({
    "feature": feature_names,
    "coefficient": coefficients,
    "absolute_importance": abs(coefficients)
}).sort_values("absolute_importance", ascending=False)

print("\nTop Factors Related to Attrition:")
print(importance.head(10)[["feature", "coefficient"]])

# Visualization: attrition by department
attrition_by_department = (
    data.groupby("department", dropna=False)["attrition"].mean() * 100
)

plt.figure(figsize=(8, 5))
attrition_by_department.plot(kind="bar")
plt.xlabel("Department")
plt.ylabel("Attrition Rate (%)")
plt.title("Employee Attrition Rate by Department")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("attrition_by_department.png", dpi=150)
plt.show()

# Visualization: satisfaction vs attrition
plt.figure(figsize=(8, 5))
plt.scatter(
    data["job_satisfaction"],
    data["working_hours_per_week"],
    c=data["attrition"],
    alpha=0.6
)
plt.xlabel("Job Satisfaction")
plt.ylabel("Working Hours per Week")
plt.title("Employee Satisfaction and Working Hours")
plt.tight_layout()
plt.savefig("satisfaction_vs_hours.png", dpi=150)
plt.show()
